#include <stdio.h>
#include <math.h>
void solver (float a , float b , float c , float* p1 , float* p2);

int main()
{ float x1,x2,a,b,c;
  float *p1=&x1,*p2=&x2;
  printf("Enter three nums :\n");
  scanf("%f%f%f",&a,&b,&c);
  float delta = b*b - 4*a*c;
  float R=-(c/b);
   if((a==0) && (b==0))
     printf("Erorr\n");
   else if(a==0)
     printf("nums of roots: 1\nThe root is:%f",R);
   else if ( delta < 0)
     printf("This eguation has no real roots\n");
   else if(delta==0)
    {   
      solver(a,b,c,p1,p2);
      printf("nums of roots: 1\nThe root is:%f",*p1);
    }
     else 
     {  
      solver(a,b,c,p1,p2);
      printf("nums of roots: 2\nThe roots are:%f%f",*p1,*p2);
     }
     
}

void solver ( float a , float b , float c , float* p1 , float* p2)
{ 
 float delta=b*b-4*a*c;
   
    if(delta==0)
     *p1=(-b)/(2*a);
    else
    { 
     *p1=((-b) + sqrt(delta))/(2*a);
     *p2=((-b) - sqrt(delta))/(2*a);
    }

}
